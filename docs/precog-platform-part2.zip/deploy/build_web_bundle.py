"""Builds the web app and copies it into lead-core/backend/web_dist/, so the backend can serve it from ONE host (PRD FR-API-9, NFR-HOST).

Run from the repo root before you deploy (and again whenever the web code or web/.env.local changes):
    python deploy/build_web_bundle.py
It runs "npm ci" and "npm run build" in web/, then replaces lead-core/backend/web_dist/ with the result. Commit that folder on your branch.
The Firebase web settings in web/.env.local are baked into the build, so fill them in first if you want push notifications on the hosted app.
"""
import shutil
import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
BUNDLE = REPO_ROOT / "lead-core" / "backend" / "web_dist"


def copy_dist(source, target):
    """Replaces `target` with a copy of `source`. Refuses if the source is not a built app. Returns the number of files copied."""
    source, target = Path(source), Path(target)
    if not (source / "index.html").is_file():
        raise SystemExit("%s has no index.html: the web app was not built" % source)
    if target.exists():
        shutil.rmtree(target)
    shutil.copytree(source, target)
    return sum(1 for p in target.rglob("*") if p.is_file())


def main():
    web = REPO_ROOT / "web"
    npm = "npm.cmd" if sys.platform == "win32" else "npm"
    for command in ([npm, "ci"], [npm, "run", "build"]):
        print("web> " + " ".join(command))
        if subprocess.run(command, cwd=web).returncode != 0:
            raise SystemExit("The web build failed. Read the message above.")
    count = copy_dist(web / "dist", BUNDLE)
    print("Copied %d files to %s" % (count, BUNDLE))
    print("Next: git add lead-core/backend/web_dist ; git commit ; push and merge, then deploy.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
